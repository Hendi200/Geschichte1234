
import React from 'react';

// This component is currently unused in favor of the persistent SidebarNav.
// Keeping it empty to avoid errors.
const MobileNav: React.FC = () => {
  return null;
};

export default MobileNav;
